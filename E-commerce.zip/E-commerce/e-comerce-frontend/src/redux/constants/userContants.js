export const SET_USER = 'SET_USER'
export const SET_INITIAL_STATE = 'SET_INITIAL_STATE'
export const USER_RESET = 'USER_RESET'
